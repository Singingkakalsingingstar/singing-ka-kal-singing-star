document.getElementById("idolForm").addEventListener("submit", function (e) {
    e.preventDefault();

    alert(
        "🎉 Registration Successful!\n\n" +
        "Thank you for registering for the FREE Singing Reality Show.\n" +
        "Our team will contact you soon."
    );

    this.reset();
});